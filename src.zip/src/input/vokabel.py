class Vokabel:

    def __init__(self, idx, text_a, text_b, text_a_lang, text_b_lang):
        self.idx = idx
        self.text_a = text_a
        self.text_b = text_b
        self.text_a_lang = text_a_lang
        self.text_b_lang = text_b_lang
