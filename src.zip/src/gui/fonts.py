from tkinter import Tk, font
root = Tk()
print (font.families())
